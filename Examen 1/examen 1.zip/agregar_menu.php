<?php
include("conexion.php");
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style1.css">
    <title>Agregar Alumno</title>
</head>
<body>
      <div class="container">
    <h1>Agregar Alumno</h1>
    <div class="table-container">

    <form action="guardar_cotizacion.php" method="POST">
        <label>Nombre completo</label>
        <input type="text" name="Tacos" required>
        <br><br>
         <label>Calificación parcial 1</label>
        <input type="text" name="Descripcion" required>
        <br><br>
        <label>Calificación parcial 2</label>
        <input type="text" name="Precio" required>
        <br><br>
     <label>Calificación parcial 3</label>
        <input type="text" name="Proporcion" required>
        <label>Calificación semestral</label>
        <input type="text" name="Proporcion" required>
        <br><br>
        <button type="submit">Guardar cotización</button>
    </form>
    

</body>
</html>